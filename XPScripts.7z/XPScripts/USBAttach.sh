#!/bin/sh

mpv --no-video "/media/fabx/517454AE65063897/WD 1TB Dati/Game Music Collection/Windows XP Sounds/Windows XP Hardware Insert.mp3"


