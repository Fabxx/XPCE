#!/bin/sh

mpv --no-video "/path/to/Windows XP Hardware Insert.mp3"


