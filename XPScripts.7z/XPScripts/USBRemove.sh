#!/bin/sh

mpv --no-video "/path/to/Windows XP Sounds/Windows XP Hardware Remove.mp3"


