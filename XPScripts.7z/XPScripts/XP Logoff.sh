#!/bin/bash

mpv --no-video "/path/to/Windows XP Sounds/Windows XP Logoff Sound.mp3"
